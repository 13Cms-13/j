
import random

def generate_shulker_password() -> str:
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(6)])
    return f"WitherCloud{random_numbers}"

def generate_custom_password(prefix: str = "WitherCloud", length: int = 6) -> str:

    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(length)])
    return f"{prefix}{random_numbers}"

if __name__ == "__main__":
    # Test password generation
    for i in range(5):
        print(f"Password {i+1}: {generate_shulker_password()}")
