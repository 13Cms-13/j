# Flow Cloud Pass Changer - Discord Bot

Automated Microsoft Account password recovery bot for Discord.

## Setup

1. Create a Discord bot at https://discord.com/developers/applications
2. Copy the token and set DISCORD_TOKEN environment variable
3. Install dependencies: `pip install -r requirements-bot.txt`
4. Run: `python bot.py`

## Commands

- `.set-log #channel` - Set logging channel
- `.recover email:password` - Start password recovery
- `.set-webhook url` - Set webhook for results

## Features

- Scrapes Microsoft/Skype/Xbox account info
- Automated CAPTCHA handling
- OTP verification
- Password reset
- Discord embed logging
- Webhook notifications

**Created with Flow Cloud Pass Changer By SeriesV2**
